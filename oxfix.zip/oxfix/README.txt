AS WE ALL KNOW OX HAS DROPPED ALL QBCORE SUPPORT.

HERE IS THE LATEST VERSIONS OF OX_INVENTORY, OX_TARGET, AND OX_DOORLOCK WORKING WITH QBCORE.



STEP ONE: MAKE SURE YOU MAKE A BACKUP OF YOUR CURRENT OX SCRIPTS.



STEP TWO: DELETE YOUR OX SCRIPTS FROM RESOURCE FOLDER.



STEP THREE: PUT THE FIXED OX SCRIPTS BACK INTO YOUR RESOURCE FOLDER.



STEP FOUR: GO TO YOUR BACKUP COPIES AND COPY AND REPLACE ALL YOUR ITEMS,IMAGES,SHOPS, ECT OVER TO THE NEW OX FILES.





--- YOU ONLY HAVE TO DO STEP FIVE AND SIX IF YOU ARE RUNNING THE LATEST VERSION OF QB-CORE ---

IF YOU ARE ON A FRESH SERVER BUILD AND HAVE NOT MODIFIED YOUR FUNCTION AND EVENTS LUA YOU CAN JUST REPLACE THE WHOLE LUA WITH THE ONE PROVIDED.

OTHERWISE PROCEED TO STEP FIVE AND SIX.





STEP FIVE: GO TO [QB] QB-CORE/SERVER/FUNCTIONS AND MAKE A BACKUP COPY. AFTER MAKING A BACKUP COPY SEARCH CREATEUSEABLEITEM 

AND REPLACE THIS:

function QBCore.Functions.CreateUseableItem(item, data)
    local rawFunc = nil

    if type(data) == 'table' then
        if rawget(data, '__cfx_functionReference') then
            rawFunc = data
        elseif data.cb and rawget(data.cb, '__cfx_functionReference') then
            rawFunc = data.cb
        elseif data.callback and rawget(data.callback, '__cfx_functionReference') then
            rawFunc = data.callback
        end
    elseif type(data) == 'function' then
        rawFunc = data
    end

    if rawFunc then
        QBCore.UsableItems[item] = {
            func = rawFunc,
            resource = GetInvokingResource()
        }
    end
end

WITH THIS:

function QBCore.Functions.CreateUseableItem(item, data)
    QBCore.UsableItems[item] = data
end







STEP SIX: GO TO [QB] QB-CORE/SERVER/EVENTS AND MAKE A BACKUP COPY. AFTER MAKING A BACKUP COPY SEARCH AddEventHandler("onResourceStop"

AND REPLACE THIS:

AddEventHandler("onResourceStop", function(resName)
    for i,v in pairs(QBCore.UsableItems) do
        if v.resource == resName then
            QBCore.UsableItems[i] = nil
        end
    end
end)

WITH THIS:

AddEventHandler("onResourceStop", function(resName)
    for i,v in pairs(QBCore.UsableItems) do
        if v.resource == resName then
            QBCore.UsableItems[i] = nil
        end
    end
end)




AND YOU'RE ALL SET. RESTART SERVER AND TEST.
 

